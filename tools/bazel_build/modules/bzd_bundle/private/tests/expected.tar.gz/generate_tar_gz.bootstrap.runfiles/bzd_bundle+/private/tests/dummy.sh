echo "from dummy.sh"
cat "$(dirname $(realpath $0))/dummy.txt"
